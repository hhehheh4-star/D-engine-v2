# Domino Engine — Tahap 1

Overlay mengambang untuk petunjuk gaple (4 pemain, double-six, giliran searah jarum jam).
Android 8+ (target Android 11). Tidak menekan layar / bermain otomatis.

## Build lewat GitHub
1. Buat repo baru di GitHub, upload semua isi folder ini (termasuk folder `.github`).
2. Tab **Actions** -> workflow **Build APK** jalan otomatis (atau Run workflow).
3. Selesai -> buka run-nya -> **Artifacts** -> `DominoEngine-debug-apk` -> unduh, ekstrak, install `app-debug.apk`.

## Pasang & izin
1. Buka app -> "Izinkan tampil di atas aplikasi lain" -> aktifkan untuk Domino Engine.
2. "Aktifkan Aksesibilitas" -> cari Domino Engine -> aktifkan (sebagai cadangan overlay; dipakai screenshot di Tahap 2).
3. "Mulai Overlay" lalu buka game.

## Cara main
- Awal ronde: tap 7 kartu lu di grid, pilih siapa yang mulai.
- Giliran lawan: tap angka ujung baru -> tap panah kiri/kanan (atau PASS). Giliran pindah otomatis.
- Giliran lu: kartu terbaik muncul (hijau, ★). Mainkan di game, lalu tap kartu itu di panel.
- Header "Giliran: ..." bisa di-tap untuk koreksi giliran. UNDO untuk salah tap. ⟲ untuk reset ronde.

## Struktur
- core/  : Tiles, Rules, Session (aturan + state + undo), tanpa dependensi Android
- ai/    : HiddenSampler (inferensi lawan dari pass), MonteCarloEngine
- overlay/: OverlayController, OverlayService (foreground), DominoAccessibilityService
- ui/    : MainActivity
- test   : app/src/test (aturan, sampler, Monte Carlo)

## Belum ada (Tahap 2/3)
- Baca 7 kartu awal otomatis dari screenshot
- Deteksi pass otomatis dari badge jumlah kartu lawan
- Opasitas/ukuran overlay yang bisa diatur

## Tahap 2 — Scan 7 kartu otomatis (offline)
- Di fase input kartu ada tombol **📷 SCAN 7 KARTU**. Satu tap: panel disembunyikan sebentar, screenshot diambil lewat
  Aksesibilitas (`takeScreenshot`, Android 11+, tanpa dialog rekam layar, tanpa internet), 7 kartu dibaca dari titiknya,
  lalu langsung lompat ke "pilih siapa yang mulai". Kartu yang terbaca ditampilkan di layar itu; salah? tap "↶ Ubah kartu".
- Kalau terbaca kurang dari 7 atau ada yang meragukan, kartu yang terbaca tetap diisi dan sisanya diisi manual di grid.
- Tidak ada model/OpenCV: murni hitung piksel (`vision/HandScanner.kt`). Gambar tidak disimpan dan tidak dikirim ke mana pun.
- Tervalidasi pada 1 screenshot nyata (7/7 benar) + variasi skala/JPEG/blur/kecerahan. BELUM dicoba di HP dan belum dicoba di
  game/tema kartu lain. Kartu harus tegak (vertikal) seperti di contoh.
- `tools/scan_reference.py` = versi Python acuan algoritma yang sama (untuk menguji screenshot baru di laptop).

## Tahap 3 — Input kartu bergambar + scan meja (offline)
**Input giliran lawan (papan sudah ada kartu):** dua bagian bergambar kartu, KIRI dan KANAN. Hanya kartu yang MUNGKIN yang
tampil (belum keluar, bukan kartu lu, cocok dengan ujung, dan tidak mengandung angka yang pemain itu terbukti tidak punya
dari riwayat pass). Tap 1 kartu = sisi dan pemain langsung tercatat. Keypad angka hanya dipakai untuk kartu PERTAMA ronde.
Kalau kartu "mustahil" ternyata dilempar (salah catat pass), tap "Tampilkan semua kartu".

**📷 SCAN MEJA:** panel disembunyikan 0,2 dtk, screenshot (Aksesibilitas), semua kartu meja dibaca dari garis tengahnya,
dibandingkan dengan kartu yang sudah tercatat. Kartu baru dicatat atas nama pemain yang sedang giliran.
- Sisi ditentukan dari ujung meja. Kalau satu kartu cocok di dua ujung, muncul pilihan KIRI/KANAN bergambar.
- Kalau 2-3 kartu baru, urutan dicari yang sah secara aturan; kalau tidak unik, tidak ditebak (input manual).
- Kartu tangan lu yang terbaca di meja diabaikan; kartu dobel / titik tidak jelas ditandai, bukan dipakai.
- Pemain yang dikira jalan ternyata PASS: tap "↻ Px sebenarnya PASS" (batalkan, catat pass, kartu pindah ke pemain berikutnya).
**AUTO:** cek meja tiap ~1 dtk saat giliran lawan. Panel TIDAK disembunyikan, jadi geser panel ke area meja yang kosong;
kartu yang tertutup panel dilewati. Default OFF.

Validasi (di laptop, mirror algoritma): meja penuh 22/22 kartu benar di 3 ukuran layar, rantai nyambung; meja kosong = 0 kartu;
kartu tangan dan meja tidak tercampur. Kode Kotlin BELUM dikompilasi / dicoba di HP. `tools/table_reference.py` = acuan Python.
