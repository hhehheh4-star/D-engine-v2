# Mirrors the Kotlin TableScanner exactly (component-based, size-adaptive, cream-sides check)
from PIL import Image
import numpy as np, sys
from scipy import ndimage as ndi

def is_cream(r,g,b): return r>=165 and g>=165 and b>=125 and (r-b)>=8 and (r-b)<=75 and abs(r-g)<=16

def scan(im, excl=None):
    H,W,_=im.shape
    ox,oy=int(W*0.12),int(H*0.15); ex,ey=int(W*0.88),int(H*0.90)
    reg=im[oy:ey,ox:ex]; h,w,_=reg.shape
    r,g,b=reg[...,0],reg[...,1],reg[...,2]
    red=(r>=80)&(r>=g+45)&(r>=b+45)
    if excl is not None:
        l,t,rr,bb=excl; red[max(0,t-oy):max(0,bb-oy),max(0,l-ox):max(0,rr-ox)]=False
    lab,n=ndi.label(red)
    comps=[]
    for i,sl in enumerate(ndi.find_objects(lab)):
        bh=sl[0].stop-sl[0].start; bw=sl[1].stop-sl[1].start
        area=int((lab[sl]==i+1).sum())
        comps.append((sl[1].start,sl[0].start,bw,bh,area))
    def cream_at(x,y):
        # 'inside a tile' = not table-green (cream body or red pip); a shadow line at a tile edge has green on one side
        if x<0 or y<0 or x>=w or y>=h: return False
        rr_,gg_,bb_=int(reg[y,x,0]),int(reg[y,x,1]),int(reg[y,x,2])
        return not (gg_>=rr_+20)
    cands=[]
    for (x,y,bw,bh,area) in comps:
        L=max(bw,bh); T=min(bw,bh)
        if not (0.02*H<=L<=0.06*H): continue
        if T>max(3,int(0.005*H)): continue
        if L/max(1,T)<8: continue
        if area<0.6*L*T: continue
        horiz=bw>bh
        cnt=0
        for f in (0.25,0.5,0.75):
            if horiz:
                px_=x+int(bw*f); d=T+4
                cnt+=cream_at(px_,y-d)+cream_at(px_,y+bh-1+d)
            else:
                py_=y+int(bh*f); d=T+4
                cnt+=cream_at(x-d,py_)+cream_at(x+bw-1+d,py_)
        if cnt>=5: cands.append((x,y,bw,bh,horiz,L))
    if not cands: return [],0
    Ls=sorted(c[5] for c in cands); unit=Ls[len(Ls)//2]
    cands=[c for c in cands if 0.85*unit<=c[5]<=1.15*unit]
    half=int(unit*1.25)
    pipc=[]
    for (x,y,bw,bh,area) in comps:
        if area>=0.03*unit*unit and area<=0.35*unit*unit and 0.55<=bw/bh<=1.8 and area>=0.3*bw*bh:
            pipc.append((x+bw/2.0,y+bh/2.0))
    def count(xa,xb,ya,yb): return sum(1 for (cx,cy) in pipc if xa<=cx<xb and ya<=cy<yb)
    out=[]
    m=int(unit*0.12)
    for (x,y,bw,bh,horiz,L) in cands:
        cx=x+bw//2; cy=y+bh//2
        if horiz:
            a=count(x-m,x+bw+m,cy-half+int(unit*0.08),cy-int(unit*0.1))
            c=count(x-m,x+bw+m,cy+int(unit*0.1),cy+half-int(unit*0.08))
            out.append(('V',cx+ox,cy+oy,a,c))
        else:
            a=count(cx-half+int(unit*0.08),cx-int(unit*0.1),y-m,y+bh+m)
            c=count(cx+int(unit*0.1),cx+half-int(unit*0.08),y-m,y+bh+m)
            out.append(('H',cx+ox,cy+oy,a,c))
    return sorted(out,key=lambda t:(t[2]//60,t[1])),unit
if __name__=="__main__":
    t,u=scan(np.array(Image.open(sys.argv[1]).convert('RGB')).astype(int))
    print("unit",u,"tiles",len(t)); print(" ".join("%d|%d"%(a,b) for _,_,_,a,b in t))
    keys=[tuple(sorted((a,b))) for _,_,_,a,b in t]; print("dups",[k for k in set(keys) if keys.count(k)>1])
