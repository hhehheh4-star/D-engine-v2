package com.domino.engine.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Kartu domino mini bergambar titik (horizontal): angka a di kiri, b di kanan. */
class DominoCardView(context: Context, private val a: Int, private val b: Int) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val cBody = Color.parseColor("#F3F1DC")
    private val cLine = Color.parseColor("#B5483F")
    private val cPip = Color.parseColor("#C62828")

    init {
        isClickable = true
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h * 0.18f
        paint.style = Paint.Style.FILL
        paint.color = cBody
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, paint)
        paint.color = cLine
        paint.strokeWidth = max(2f, h * 0.05f)
        canvas.drawLine(w / 2f, h * 0.12f, w / 2f, h * 0.88f, paint)
        drawHalf(canvas, a, 0f, w / 2f, h)
        drawHalf(canvas, b, w / 2f, w / 2f, h)
    }

    private fun drawHalf(canvas: Canvas, v: Int, x0: Float, cw: Float, ch: Float) {
        if (v <= 0) return
        val pad = min(cw, ch) * 0.20f
        val gx = (cw - 2f * pad) / 2f
        val gy = (ch - 2f * pad) / 2f
        val radius = min(cw, ch) * 0.11f
        paint.color = cPip
        paint.style = Paint.Style.FILL
        // kode posisi = baris * 3 + kolom pada grid 3x3
        val spots: IntArray = when (v) {
            1 -> intArrayOf(4)
            2 -> intArrayOf(0, 8)
            3 -> intArrayOf(0, 4, 8)
            4 -> intArrayOf(0, 2, 6, 8)
            5 -> intArrayOf(0, 2, 4, 6, 8)
            else -> intArrayOf(0, 2, 3, 5, 6, 8)
        }
        for (code in spots) {
            val col = code % 3
            val row = code / 3
            canvas.drawCircle(x0 + pad + gx * col, pad + gy * row, radius, paint)
        }
    }
}
