package com.domino.engine.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.domino.engine.ai.Analysis
import com.domino.engine.ai.MonteCarloEngine
import com.domino.engine.core.EndReason
import com.domino.engine.core.GameState
import com.domino.engine.core.Move
import com.domino.engine.core.Phase
import com.domino.engine.core.Rules
import com.domino.engine.core.Session
import com.domino.engine.core.Side
import com.domino.engine.core.Tiles
import com.domino.engine.vision.ScanOutcome
import com.domino.engine.vision.TableOutcome
import com.domino.engine.vision.ScreenGrabber
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Panel overlay: bubble kecil yang bisa digeser, bisa dibuka jadi panel input (keypad 0-6)
 * dan panel rekomendasi. Semua dibangun dari View biasa (tanpa XML) supaya ringan.
 *
 * Alur: input 7 kartu -> pilih pemain awal -> tiap giliran lawan: tap angka ujung baru + arah
 * (atau PASS). Giliran kita: engine menghitung di background, tap kartu yang lu mainkan di game.
 */
class OverlayController(
    private val ctx: Context,
    windowType: Int,
    private val budgetMs: Long,
    private val onClose: () -> Unit
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val session = Session()
    private val engine = MonteCarloEngine()
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val token = AtomicInteger(0)
    private val density = ctx.resources.displayMetrics.density
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val root = FrameLayout(ctx)
    private val params = WindowManager.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT,
        ViewGroup.LayoutParams.WRAP_CONTENT,
        windowType,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    )

    private var expanded = true
    private var dragging = false
    private var pendingRender = false
    private var destroyed = false
    private var stateSeq = 0
    private var analysis: Analysis? = null
    private var selA = -1
    private var selB = -1
    private var message: String? = null
    private var showDetail = false
    private var resetArmed = false
    private var scanning = false
    private var autoScan = false
    private var tableBusy = false
    private var pendingTile = -1
    private var showAllCards = false
    private var scanStatus = ""
    private var lastApplied: List<Move> = emptyList()
    private var lastAppliedPlayer = -1
    private var lastAppliedSeq = -1

    private val clearMessage = Runnable {
        message = null
        render()
    }
    private val autoTick = Runnable { autoTickBody() }
    private val disarmReset = Runnable {
        resetArmed = false
        render()
    }

    private val cPanel = Color.parseColor("#F2101820")
    private val cBtn = Color.parseColor("#2F3B4A")
    private val cOff = Color.parseColor("#1C232C")
    private val cAccent = Color.parseColor("#1E88E5")
    private val cGood = Color.parseColor("#2E9E5B")
    private val cWarn = Color.parseColor("#C0392B")
    private val cArrow = Color.parseColor("#7B5CC4")
    private val cText = Color.WHITE
    private val cMuted = Color.parseColor("#9FB0C3")

    private val playerNames = listOf("P1 (gue)", "P2 kiri", "P3 atas", "P4 kanan")

    init {
        params.gravity = Gravity.TOP or Gravity.START
        params.x = dp(8)
        params.y = dp(24)
    }

    // ------------------------------------------------------------------ lifecycle

    fun show() {
        wm.addView(root, params)
        render()
    }

    fun destroy() {
        destroyed = true
        token.incrementAndGet()
        handler.removeCallbacksAndMessages(null)
        executor.shutdownNow()
        try {
            wm.removeView(root)
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ state changes

    private fun afterChange() {
        stateSeq++
        analysis = null
        selA = -1
        selB = -1
        pendingTile = -1
        token.incrementAndGet()
        val s = session.state
        if (s.phase == Phase.PLAYING && s.turn == 0) startAnalysis()
        render()
    }

    private fun startAnalysis() {
        if (destroyed) return
        val seq = stateSeq
        val my = token.incrementAndGet()
        val snapshot = session.state
        try {
            executor.execute {
                engine.analyze(snapshot, budgetMs, { token.get() != my }) { a ->
                    handler.post {
                        if (!destroyed && seq == stateSeq) {
                            analysis = a
                            render()
                        }
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun flash(msg: String) {
        message = msg
        handler.removeCallbacks(clearMessage)
        handler.postDelayed(clearMessage, 2500)
        render()
    }

    private fun act(error: String?) {
        if (error != null) flash(error) else afterChange()
    }

    // ------------------------------------------------------------------ rendering

    private fun render() {
        if (destroyed) return
        if (dragging) {
            pendingRender = true
            return
        }
        root.removeAllViews()
        if (!expanded) {
            root.addView(buildBubble())
        } else {
            root.addView(buildPanel())
        }
    }

    private fun buildBubble(): View {
        val tv = TextView(ctx)
        tv.text = "DE"
        tv.gravity = Gravity.CENTER
        tv.setTextColor(cText)
        tv.textSize = 16f
        tv.typeface = Typeface.DEFAULT_BOLD
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(cAccent)
        tv.background = bg
        tv.layoutParams = FrameLayout.LayoutParams(dp(48), dp(48))
        makeDraggable(tv) {
            expanded = true
            render()
        }
        return tv
    }

    private fun buildPanel(): View {
        val s = session.state
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.background = rounded(cPanel, 12)
        col.setPadding(dp(6), dp(4), dp(6), dp(6))
        col.layoutParams = FrameLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT)

        col.addView(buildHeader(s))
        col.addView(buildStatus(s))
        when (s.phase) {
            Phase.HAND_ENTRY -> col.addView(buildHandEntry(s))
            Phase.PICK_STARTER -> col.addView(buildStarterPick())
            Phase.PLAYING -> col.addView(
                if (s.turn == 0) buildMyTurn(s) else if (s.boardEmpty) buildOppPad(s) else buildOppCards(s)
            )
            Phase.OVER -> col.addView(buildOver(s))
        }
        return col
    }

    private fun buildHeader(s: GameState): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val title = TextView(ctx)
        title.text = "≡ Domino Engine"
        title.setTextColor(cMuted)
        title.textSize = 12f
        title.setPadding(dp(4), dp(6), dp(4), dp(6))
        title.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        makeDraggable(title)
        row.addView(title)

        if (s.phase == Phase.PLAYING) {
            row.addView(chip("Giliran: ${playerNames[s.turn]}", cAccent, dp(110), dp(30), true, 11f) {
                act(session.setTurn((s.turn + 1) % 4))
            })
        }
        row.addView(
            chip(if (resetArmed) "Yakin?" else "⟲", if (resetArmed) cWarn else cBtn, dp(if (resetArmed) 50 else 30), dp(30), true, 13f) {
                if (resetArmed) {
                    resetArmed = false
                    handler.removeCallbacks(disarmReset)
                    session.newRound()
                    afterChange()
                } else {
                    resetArmed = true
                    handler.postDelayed(disarmReset, 3000)
                    render()
                }
            }
        )
        row.addView(chip("–", cBtn, dp(30), dp(30), true, 14f) {
            expanded = false
            render()
        })
        row.addView(chip("✕", cWarn, dp(30), dp(30), true, 13f) { onClose() })
        return row
    }

    private fun buildStatus(s: GameState): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(4), 0, dp(4), dp(2))

        if (s.phase == Phase.PLAYING || s.phase == Phase.OVER) {
            val ends = if (s.boardEmpty) "Papan kosong" else "Kiri ${s.left}   ◄ ►   Kanan ${s.right}"
            col.addView(label(ends, 15f, cText, true))
            col.addView(
                label(
                    "Sisa kartu: " + (0..3).joinToString("  ") { "P${it + 1}:${s.counts[it]}" },
                    11f, cMuted, false
                )
            )
            val lacks = (1..3).filter { s.forbiddenNumbers(it).isNotEmpty() }
            if (lacks.isNotEmpty()) {
                col.addView(
                    label(
                        "Tidak punya: " + lacks.joinToString("  ") { p ->
                            "P${p + 1}:" + s.forbiddenNumbers(p).joinToString(",")
                        },
                        11f, cMuted, false
                    )
                )
            }
        }
        if (s.phase == Phase.PLAYING && lastApplied.isNotEmpty() && lastAppliedSeq == stateSeq && lastAppliedPlayer in 1..3) {
            col.addView(
                chip("↻ P${lastAppliedPlayer + 1} sebenarnya PASS", cBtn, dp(220), dp(30), true, 11f) { fixPass() }
            )
        }
        val msg = message
        if (msg != null) {
            val good = msg.startsWith("✓")
            col.addView(label(if (good) msg else "⚠ $msg", 12f, if (good) Color.parseColor("#7CE0A3") else Color.parseColor("#FFB74D"), true))
        }
        return col
    }

    private fun buildHandEntry(s: GameState): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label("Pilih 7 kartu lu (${Integer.bitCount(s.myHand)}/7)", 13f, cText, true))
        col.addView(chip("📷 SCAN 7 KARTU (otomatis)", cGood, dp(220), dp(40), !scanning, 13f) { startScan() })
        for (hi in 0..6) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            for (lo in 0..hi) {
                val t = Tiles.index(lo, hi)
                val sel = ((s.myHand shr t) and 1) == 1
                row.addView(chip("$lo-$hi", if (sel) cAccent else cBtn, dp(36), dp(28), true, 12f) {
                    act(session.toggleHandTile(t))
                })
            }
            col.addView(row)
        }
        return col
    }

    // ---- scan kartu tangan dari layar (offline) ----

    private fun handText(mask: Int): String =
        (0 until Tiles.COUNT).filter { ((mask shr it) and 1) == 1 }.joinToString("  ") { Tiles.label(it) }

    private fun startScan() {
        if (scanning || destroyed) return
        val svc = DominoAccessibilityService.instance
        if (svc == null) {
            flash("Aktifkan Aksesibilitas Domino Engine dulu")
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            flash("Scan layar butuh Android 11 ke atas")
            return
        }
        scanning = true
        root.visibility = View.INVISIBLE   // sembunyikan panel supaya tidak menutupi kartu di screenshot
        handler.postDelayed({
            if (destroyed) return@postDelayed
            try {
                ScreenGrabber.grab(svc, executor) { outcome ->
                    handler.post { onScanResult(outcome) }
                }
            } catch (e: Exception) {
                onScanResult(ScanOutcome(0, emptyList(), emptyList(), "Scan gagal: " + e.message))
            }
        }, 220)
    }

    private fun onScanResult(o: ScanOutcome) {
        scanning = false
        if (destroyed) return
        root.visibility = View.VISIBLE
        val err = o.error
        if (err != null) {
            flash(err)
            return
        }
        val n = Integer.bitCount(o.mask)
        val e2 = session.setHandMask(o.mask)
        if (e2 != null) {
            flash(e2)
            return
        }
        afterChange()
        val extra = if (o.problems.isEmpty()) "" else " (" + o.problems.joinToString("; ") + ")"
        flash(
            if (n == 7) "✓ Terbaca 7 kartu. Cek, lalu pilih pemain awal.$extra"
            else "Terbaca $n/7 kartu. Tap kartu yang kurang.$extra"
        )
    }

    private fun buildStarterPick(): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label("Siapa yang mulai ronde ini?", 13f, cText, true))
        col.addView(label("Kartu lu: " + handText(session.state.myHand), 11f, cMuted, false))
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        val short = listOf("P1\ngue", "P2\nkiri", "P3\natas", "P4\nkanan")
        for (p in 0..3) {
            row.addView(chip(short[p], cAccent, dp(66), dp(52), true, 13f) {
                act(session.setStarter(p))
            })
        }
        col.addView(row)
        col.addView(chip("↶ Ubah kartu", cBtn, dp(120), dp(34), session.canUndo(), 12f) {
            session.undo()
            afterChange()
        })
        return col
    }

    // ---- giliran lawan: keypad ----

    private fun available(s: GameState, t: Int): Boolean =
        ((s.played shr t) and 1) == 0 && ((s.myHand shr t) and 1) == 0

    private fun numberEnabled(s: GameState, n: Int): Boolean {
        if (s.boardEmpty) return true
        return available(s, Tiles.index(s.left, n)) || available(s, Tiles.index(s.right, n))
    }

    private fun arrowEnabled(s: GameState, side: Side): Boolean {
        if (selA < 0 || s.boardEmpty) return false
        val end = if (side == Side.LEFT) s.left else s.right
        return available(s, Tiles.index(end, selA))
    }

    private fun onNumber(s: GameState, n: Int) {
        if (s.boardEmpty) {
            if (selA < 0) {
                selA = n
            } else if (selB < 0) {
                selB = n
            } else {
                selA = n
                selB = -1
            }
        } else {
            selA = if (selA == n) -1 else n
        }
        render()
    }

    private fun onArrow(s: GameState, side: Side) {
        if (selA < 0) return
        val end = if (side == Side.LEFT) s.left else s.right
        act(session.play(Tiles.index(end, selA), side))
    }

    private fun buildOppPad(s: GameState): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val hint = if (s.boardEmpty) {
            "Kartu pertama: tap 2 angka lalu OK"
        } else {
            "Tap angka ujung baru, lalu arah"
        }
        col.addView(label("${playerNames[s.turn]} main apa?  $hint", 11f, cMuted, false))

        val wrap = LinearLayout(ctx)
        wrap.orientation = LinearLayout.HORIZONTAL
        val sz = dp(46)

        val grid = LinearLayout(ctx)
        grid.orientation = LinearLayout.VERTICAL
        fun numChip(n: Int): TextView {
            val sel = (selA == n) || (s.boardEmpty && selB == n)
            return chip("$n", if (sel) cAccent else cBtn, sz, sz, numberEnabled(s, n), 20f) { onNumber(s, n) }
        }
        for (nums in listOf(listOf(1, 2, 3), listOf(4, 5, 6))) {
            val r = LinearLayout(ctx)
            r.orientation = LinearLayout.HORIZONTAL
            for (n in nums) r.addView(numChip(n))
            grid.addView(r)
        }
        val r0 = LinearLayout(ctx)
        r0.orientation = LinearLayout.HORIZONTAL
        val spacer = View(ctx)
        spacer.layoutParams = LinearLayout.LayoutParams(sz + dp(4), sz)
        r0.addView(spacer)
        r0.addView(numChip(0))
        grid.addView(r0)
        wrap.addView(grid)

        val side = LinearLayout(ctx)
        side.orientation = LinearLayout.VERTICAL
        val w = dp(112)
        val h = sz
        if (s.boardEmpty) {
            val a = if (selA >= 0) "$selA" else "?"
            val b = if (selB >= 0) "$selB" else "?"
            side.addView(label("Kartu: $a-$b", 16f, cText, true))
            side.addView(chip("OK", cGood, w, h, selA >= 0 && selB >= 0, 18f) {
                act(session.play(Tiles.index(selA, selB), Side.FIRST))
            })
        } else {
            side.addView(chip("◄ KIRI", cArrow, w, h, arrowEnabled(s, Side.LEFT), 16f) { onArrow(s, Side.LEFT) })
            side.addView(chip("KANAN ►", cArrow, w, h, arrowEnabled(s, Side.RIGHT), 16f) { onArrow(s, Side.RIGHT) })
        }
        val bottom = LinearLayout(ctx)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.addView(chip("PASS", cWarn, dp(54), h, !s.boardEmpty, 13f) { act(session.pass()) })
        bottom.addView(chip("UNDO", cBtn, dp(54), h, session.canUndo(), 12f) {
            session.undo()
            afterChange()
        })
        side.addView(bottom)
        wrap.addView(side)
        col.addView(wrap)
        col.addView(buildScanBar(s))
        return col
    }

    // ---- giliran lawan: kartu bergambar (hanya kartu yang mungkin) ----

    private fun buildOppCards(s: GameState): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label("${playerNames[s.turn]} main apa? Tap kartunya", 12f, cText, true))
        if (pendingTile >= 0) {
            col.addView(buildPendingChoice(s))
            col.addView(buildScanBar(s))
            return col
        }
        val forb = if (showAllCards) emptySet<Int>() else s.forbiddenNumbers(s.turn)
        val cand = ArrayList<Int>()
        for (t in 0 until Tiles.COUNT) {
            if (!available(s, t)) continue
            var blocked = false
            for (f in forb) if (Tiles.has(t, f)) blocked = true
            if (!blocked) cand.add(t)
        }
        if (s.left == s.right) {
            col.addView(cardSection("◄ ►  ujung ${s.left} (kiri = kanan)", cand.filter { Tiles.has(it, s.left) }, s.left, Side.LEFT))
        } else {
            col.addView(cardSection("◄ KIRI  (ujung ${s.left})", cand.filter { Tiles.has(it, s.left) }, s.left, Side.LEFT))
            col.addView(cardSection("KANAN ►  (ujung ${s.right})", cand.filter { Tiles.has(it, s.right) }, s.right, Side.RIGHT))
        }
        val lacks = s.forbiddenNumbers(s.turn)
        if (lacks.isNotEmpty()) {
            col.addView(
                chip(
                    if (showAllCards) "Sembunyikan kartu mustahil" else "Tampilkan semua kartu",
                    cBtn, dp(220), dp(28), true, 11f
                ) {
                    showAllCards = !showAllCards
                    render()
                }
            )
        }
        col.addView(buildScanBar(s))
        return col
    }

    private fun cardSection(title: String, tiles: List<Int>, end: Int, side: Side): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label(title, 11f, cMuted, true))
        if (tiles.isEmpty()) {
            col.addView(label("(tidak ada kartu yang mungkin)", 11f, cMuted, false))
            return col
        }
        var line = LinearLayout(ctx)
        for (i in tiles.indices) {
            if (i % 4 == 0) {
                line = LinearLayout(ctx)
                line.orientation = LinearLayout.HORIZONTAL
                col.addView(line)
            }
            val t = tiles[i]
            val other = Tiles.other(t, end)
            // gambar mengikuti papan: kiri = [ujung baru | cocok], kanan = [cocok | ujung baru]
            val card = if (side == Side.LEFT) DominoCardView(ctx, other, end) else DominoCardView(ctx, end, other)
            val lp = LinearLayout.LayoutParams(dp(64), dp(34))
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            card.layoutParams = lp
            card.setOnClickListener { playManual(t, side) }
            line.addView(card)
        }
        return col
    }

    private fun playManual(t: Int, side: Side) {
        val p = session.state.turn
        val e = session.play(t, side)
        if (e != null) {
            flash(e)
            return
        }
        afterChange()
        lastApplied = listOf(Move(t, side))
        lastAppliedPlayer = p
        lastAppliedSeq = stateSeq
        render()
    }

    private fun buildPendingChoice(s: GameState): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val t = pendingTile
        col.addView(label("Kartu baru ${Tiles.label(t)} cocok di dua ujung. Dipasang di sisi mana?", 12f, Color.parseColor("#FFB74D"), true))
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        val oL = Tiles.other(t, s.left)
        val oR = Tiles.other(t, s.right)
        val cl = DominoCardView(ctx, oL, s.left)
        val cr = DominoCardView(ctx, s.right, oR)
        for ((card, side) in listOf(Pair(cl, Side.LEFT), Pair(cr, Side.RIGHT))) {
            val lp = LinearLayout.LayoutParams(dp(84), dp(44))
            lp.setMargins(dp(6), dp(4), dp(6), dp(4))
            card.layoutParams = lp
            card.setOnClickListener {
                pendingTile = -1
                applySequence(listOf(Move(t, side)))
            }
            row.addView(card)
        }
        col.addView(row)
        val names = LinearLayout(ctx)
        names.orientation = LinearLayout.HORIZONTAL
        names.addView(label("◄ KIRI (ujung ${s.left})", 11f, cMuted, false))
        names.addView(label("      KANAN ► (ujung ${s.right})", 11f, cMuted, false))
        col.addView(names)
        return col
    }

    private fun buildScanBar(s: GameState): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(chip("📷 SCAN MEJA", cGood, dp(104), dp(36), !tableBusy, 12f) { startTableScan(true) })
        row.addView(
            chip(if (autoScan) "AUTO ON" else "AUTO OFF", if (autoScan) cAccent else cBtn, dp(72), dp(36), true, 11f) { toggleAuto() }
        )
        row.addView(chip("UNDO", cBtn, dp(46), dp(36), session.canUndo(), 11f) {
            session.undo()
            afterChange()
        })
        row.addView(chip("PASS", cWarn, dp(46), dp(36), !s.boardEmpty, 11f) { act(session.pass()) })
        col.addView(row)
        if (scanStatus.isNotEmpty()) col.addView(label(scanStatus, 10f, cMuted, false))
        return col
    }

    // ---- scan meja ----

    private fun toggleAuto() {
        autoScan = !autoScan
        handler.removeCallbacks(autoTick)
        if (autoScan) handler.postDelayed(autoTick, 400)
        render()
    }

    private fun autoTickBody() {
        if (destroyed || !autoScan) return
        val s = session.state
        if (expanded && s.phase == Phase.PLAYING && s.turn != 0 && pendingTile < 0 && !scanning && !tableBusy && !dragging) {
            startTableScan(false)
        }
        handler.postDelayed(autoTick, 1100)
    }

    private fun startTableScan(manual: Boolean) {
        if (destroyed || tableBusy || scanning) return
        val svc = DominoAccessibilityService.instance
        if (svc == null) {
            if (manual) flash("Aktifkan Aksesibilitas Domino Engine dulu")
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            if (manual) flash("Scan layar butuh Android 11 ke atas")
            return
        }
        tableBusy = true
        var excl: IntArray? = null
        if (manual) {
            root.visibility = View.INVISIBLE      // panel disembunyikan supaya tidak menutupi kartu meja
        } else if (root.width > 0) {
            val loc = IntArray(2)
            root.getLocationOnScreen(loc)
            excl = intArrayOf(loc[0], loc[1], loc[0] + root.width, loc[1] + root.height)
        }
        val ex = excl
        handler.postDelayed({
            if (destroyed) return@postDelayed
            try {
                ScreenGrabber.grabTable(svc, executor, ex) { outcome ->
                    handler.post { onTableResult(outcome, manual) }
                }
            } catch (e: Exception) {
                onTableResult(TableOutcome(emptyList(), 0, emptyList(), "Scan gagal: " + e.message), manual)
            }
        }, if (manual) 220L else 0L)
    }

    private fun onTableResult(o: TableOutcome, manual: Boolean) {
        tableBusy = false
        if (destroyed) return
        if (manual) root.visibility = View.VISIBLE
        val err = o.error
        if (err != null) {
            if (manual) flash(err)
            return
        }
        val status = "Meja: ${o.tiles.size} kartu terbaca" + (if (o.problems.isEmpty()) "" else " (cek: " + o.problems.joinToString("; ") + ")")
        val changed = status != scanStatus
        scanStatus = status
        applyTable(o, manual)
        if (changed && !manual) render()
    }

    private fun applyTable(o: TableOutcome, manual: Boolean) {
        val s = session.state
        if (s.phase != Phase.PLAYING) {
            if (manual) flash("Mulai ronde dulu (scan kartu tangan, lalu pilih pemain awal)")
            return
        }
        if (s.turn == 0) {
            if (manual) flash("Sekarang giliran lu. Kalau lawan sudah jalan, ketuk tombol Giliran untuk memperbaiki.")
            return
        }
        val newMask = o.mask and s.played.inv() and s.myHand.inv()
        if (newMask == 0) {
            if (manual) {
                flash(if ((o.mask and s.myHand) != 0) "Kartu tangan lu terbaca di meja, diabaikan" else "Tidak ada kartu baru di meja")
            }
            return
        }
        val tiles = ArrayList<Int>()
        for (t in 0 until Tiles.COUNT) if (((newMask shr t) and 1) == 1) tiles.add(t)
        if (tiles.size > 3) {
            flash("Terbaca ${tiles.size} kartu baru sekaligus. Cek layar atau input manual.")
            return
        }
        val seqs = resolveSequences(s, tiles)
        if (seqs.isEmpty()) {
            if (manual) {
                flash("Kartu baru " + tiles.joinToString(" ") { Tiles.label(it) } + " tidak cocok dengan ujung meja. Input manual.")
            }
        } else if (seqs.size == 1) {
            applySequence(seqs[0])
        } else if (tiles.size == 1) {
            pendingTile = tiles[0]
            render()
        } else if (manual) {
            flash("Urutan kartu baru tidak jelas. Input manual.")
        }
    }

    /** Semua urutan pemasangan yang sah untuk kartu-kartu baru (berhenti kalau sudah ada 2 = ambigu). */
    private fun resolveSequences(s: GameState, tiles: List<Int>): List<List<Move>> {
        val out = ArrayList<List<Move>>()
        fun dfs(left: Int, right: Int, remaining: List<Int>, acc: List<Move>) {
            if (out.size >= 2) return
            if (remaining.isEmpty()) {
                out.add(acc)
                return
            }
            for (t in remaining) {
                val rest = remaining.filter { it != t }
                if (left < 0) {
                    dfs(Tiles.LO[t], Tiles.HI[t], rest, acc + Move(t, Side.FIRST))
                } else {
                    val l = Tiles.has(t, left)
                    val r = Tiles.has(t, right)
                    if (l) dfs(Tiles.other(t, left), right, rest, acc + Move(t, Side.LEFT))
                    if (r && !(l && left == right)) dfs(left, Tiles.other(t, right), rest, acc + Move(t, Side.RIGHT))
                }
            }
        }
        dfs(s.left, s.right, tiles, emptyList())
        return out
    }

    private fun applySequence(seq: List<Move>) {
        val applied = ArrayList<Move>()
        val firstPlayer = session.state.turn
        val sb = StringBuilder()
        var error: String? = null
        for (mv in seq) {
            val p = session.state.turn
            val e = session.play(mv.tile, mv.side)
            if (e != null) {
                error = e
                break
            }
            applied.add(mv)
            if (sb.isNotEmpty()) sb.append("  |  ")
            val arrow = when (mv.side) {
                Side.LEFT -> "◄ "
                Side.RIGHT -> "► "
                Side.FIRST -> ""
            }
            sb.append("P").append(p + 1).append(" ").append(arrow).append(Tiles.label(mv.tile))
        }
        pendingTile = -1
        afterChange()
        if (applied.isNotEmpty()) {
            lastApplied = applied
            lastAppliedPlayer = firstPlayer
            lastAppliedSeq = stateSeq
            flash("✓ Terdeteksi: $sb")
        } else if (error != null) {
            flash(error)
        }
    }

    /** Pemain yang dikira jalan ternyata PASS: batalkan, catat pass, lalu pasang ulang kartunya ke pemain berikutnya. */
    private fun fixPass() {
        val moves = lastApplied
        if (moves.isEmpty()) return
        val who = lastAppliedPlayer
        for (i in moves.indices) session.undo()
        val e = session.pass()
        if (e != null) {
            for (mv in moves) session.play(mv.tile, mv.side)
            lastApplied = emptyList()
            afterChange()
            flash(e)
            return
        }
        var err2: String? = null
        for (mv in moves) {
            val e2 = session.play(mv.tile, mv.side)
            if (e2 != null) {
                err2 = e2
                break
            }
        }
        lastApplied = emptyList()
        afterChange()
        flash(err2 ?: "✓ P${who + 1} dicatat PASS, kartu dimainkan pemain berikutnya")
    }

    // ---- giliran kita: rekomendasi ----

    private fun moveLabel(mv: Move, s: GameState): String {
        val t = Tiles.label(mv.tile)
        return when (mv.side) {
            Side.FIRST -> t
            Side.LEFT -> if (s.left == s.right) "◄► $t" else "◄ $t"
            Side.RIGHT -> "$t ►"
        }
    }

    private fun newEnd(mv: Move, s: GameState): Int =
        if (mv.side == Side.RIGHT) Rules.rightAfter(s.left, s.right, mv.tile, mv.side)
        else if (mv.side == Side.LEFT) Rules.leftAfter(s.left, s.right, mv.tile, mv.side)
        else Tiles.LO[mv.tile]

    private fun buildMyTurn(s: GameState): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val legal = Rules.legalMoves(s.myHand, s.left, s.right)
        val a = analysis

        if (legal.isEmpty()) {
            col.addView(label("Tidak ada kartu yang bisa jalan → PASS", 13f, cText, true))
            col.addView(chip("PASS", cWarn, ViewGroup.LayoutParams.MATCH_PARENT, dp(48), true, 18f) {
                act(session.pass())
            })
            col.addView(chip("UNDO", cBtn, dp(80), dp(34), session.canUndo(), 12f) {
                session.undo()
                afterChange()
            })
            return col
        }

        val ordered: List<Move> = if (a != null && a.moves.isNotEmpty()) a.moves.map { it.move } else legal
        val evalByMove = a?.moves?.associateBy { it.move }
        col.addView(
            label(
                if (a == null) "Menghitung…  (tap kartu yang lu mainkan)" else "GILIRAN LU — tap kartu yang lu mainkan",
                12f, cText, true
            )
        )

        var row = LinearLayout(ctx)
        var i = 0
        for (mv in ordered) {
            if (i % 3 == 0) {
                row = LinearLayout(ctx)
                row.orientation = LinearLayout.HORIZONTAL
                col.addView(row)
            }
            val ev = evalByMove?.get(mv)
            val best = (i == 0 && a != null)
            var text = moveLabel(mv, s)
            if (ev != null) text += "\n${(ev.winProb * 100).roundToInt()}%"
            row.addView(chip(if (best) "★ $text" else text, if (best) cGood else cBtn, dp(90), dp(44), true, 13f) {
                act(session.play(mv.tile, mv.side))
            })
            i++
        }

        if (a != null && a.moves.isNotEmpty()) {
            val b = a.moves[0]
            val summary = "Terbaik: ${Tiles.label(b.move.tile)} → ujung ${newEnd(b.move, s)} · menang " +
                "${(b.winProb * 100).roundToInt()}% ±${(b.stdErr * 100).roundToInt()} · risiko pip " +
                "${(b.avgPips * 10).roundToInt() / 10.0}"
            col.addView(label(summary, 11f, cText, false))
            col.addView(
                label(
                    "${a.samples} simulasi · ${a.elapsedMs} ms" + if (a.done) "" else " (menghitung…)",
                    10f, cMuted, false
                )
            )
            if (!a.constraintsOk) {
                col.addView(
                    label("⚠ Kendala pass tak terpenuhi di sebagian sampel — cek input pass/kartu.", 10f, Color.parseColor("#FFB74D"), false)
                )
            }
            if (showDetail) {
                for (p in 0..2) {
                    val pr = a.numberProb[p]
                    col.addView(
                        label(
                            "P${p + 2} punya angka: " + (0..6).joinToString(" ") { "$it:${(pr[it] * 100).roundToInt()}%" },
                            10f, cMuted, false
                        )
                    )
                }
                col.addView(label("(perkiraan/probabilitas, bukan kartu yang diketahui)", 10f, cMuted, false))
            }
        }

        val bottom = LinearLayout(ctx)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.addView(chip(if (showDetail) "Sembunyikan" else "Detail lawan", cBtn, dp(100), dp(30), a != null, 11f) {
            showDetail = !showDetail
            render()
        })
        bottom.addView(chip("UNDO", cBtn, dp(70), dp(30), session.canUndo(), 11f) {
            session.undo()
            afterChange()
        })
        col.addView(bottom)
        return col
    }

    private fun buildOver(s: GameState): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val text = when (s.endReason) {
            EndReason.EMPTY_HAND ->
                if (s.winner == 0) "Ronde selesai — GUE MENANG!" else "Ronde selesai — ${playerNames[s.winner]} menang (kartu habis)"
            EndReason.BLOCKED ->
                "BLOK (4x pass berurutan). Pemenang = sisa pip terkecil — cek di game."
            EndReason.NONE -> "Ronde selesai"
        }
        col.addView(label(text, 13f, cText, true))
        col.addView(chip("Ronde baru", cGood, ViewGroup.LayoutParams.MATCH_PARENT, dp(44), true, 16f) {
            session.newRound()
            afterChange()
        })
        col.addView(chip("↶ Undo", cBtn, dp(80), dp(32), session.canUndo(), 12f) {
            session.undo()
            afterChange()
        })
        return col
    }

    // ------------------------------------------------------------------ view helpers

    private fun dp(v: Int): Int = (v * density + 0.5f).toInt()

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView {
        val tv = TextView(ctx)
        tv.text = text
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(dp(2), dp(1), dp(2), dp(1))
        return tv
    }

    private fun chip(
        text: String,
        color: Int,
        w: Int,
        h: Int,
        enabled: Boolean = true,
        size: Float = 14f,
        onClick: () -> Unit
    ): TextView {
        val tv = TextView(ctx)
        tv.text = text
        tv.gravity = Gravity.CENTER
        tv.textSize = size
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setTextColor(if (enabled) cText else Color.parseColor("#55FFFFFF"))
        tv.background = rounded(if (enabled) color else cOff, 8)
        val lp = LinearLayout.LayoutParams(w, h)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        tv.layoutParams = lp
        if (enabled) tv.setOnClickListener { onClick() }
        return tv
    }

    private fun makeDraggable(v: View, onTap: (() -> Unit)? = null) {
        var sx = 0f
        var sy = 0f
        var px = 0
        var py = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    px = params.x
                    py = params.y
                    moved = false
                    dragging = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        params.x = max(0, (px + dx).toInt())
                        params.y = max(0, (py + dy).toInt())
                        try {
                            wm.updateViewLayout(root, params)
                        } catch (e: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    val tapped = !moved && e.actionMasked == MotionEvent.ACTION_UP
                    if (tapped && onTap != null) {
                        onTap()
                    } else if (pendingRender) {
                        pendingRender = false
                        render()
                    }
                    true
                }
                else -> false
            }
        }
    }
}
