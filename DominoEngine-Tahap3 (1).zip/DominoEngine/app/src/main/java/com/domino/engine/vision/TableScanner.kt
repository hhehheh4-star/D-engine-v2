package com.domino.engine.vision

import com.domino.engine.core.Tiles
import kotlin.math.max
import kotlin.math.min

/** Satu kartu yang terbaca di meja. a/b = titik di dua sisi garis tengah. */
class TableTile(
    val a: Int,
    val b: Int,
    val cx: Int,
    val cy: Int,
    val horizontal: Boolean,
    val valid: Boolean
)

class TableScanResult(
    val tiles: List<TableTile>,
    val mask: Int,
    val problems: List<String>
)

private class DividerCand(
    val x: Int,
    val y: Int,
    val bw: Int,
    val bh: Int,
    val horiz: Boolean,
    val len: Int
)

/**
 * Pembaca kartu di MEJA, offline, murni hitung piksel.
 *  1. cari gumpalan merah; garis tengah kartu = gumpalan tipis & lurus yang berada DI DALAM kartu
 *     (bukan bayangan di tepi kartu: sisi sebelahnya hijau meja)
 *  2. ukuran kartu meja dipelajari dari garis-garis itu (median), jadi tahan terhadap kartu yang diperkecil game;
 *     garis kartu tangan jauh lebih panjang sehingga tidak ikut
 *  3. titik = gumpalan merah bulat di kiri/kanan (atau atas/bawah) garis tengah
 * Kartu miring/berbelok/double melintang tidak masalah karena tiap kartu dikenali dari garis tengahnya sendiri.
 * Kartu yang sebagian tertutup panel overlay dilewati (bukan ditebak).
 */
object TableScanner {

    private fun isRed(r: Int, g: Int, b: Int): Boolean =
        r >= 80 && r >= g + 45 && r >= b + 45

    /** "di dalam kartu" = bukan hijau meja (badan krem atau titik merah). */
    private fun insideTile(px: IntArray, w: Int, h: Int, x: Int, y: Int): Boolean {
        if (x < 0 || y < 0 || x >= w || y >= h) return false
        val p = px[y * w + x]
        val r = (p shr 16) and 0xFF
        val g = (p shr 8) and 0xFF
        return !(g >= r + 20)
    }

    /**
     * @param px piksel ARGB wilayah meja (w x h), diambil dari (ox, oy) di layar
     * @param excl area layar yang tertutup overlay kita [kiri, atas, kanan, bawah] atau null
     */
    fun scan(px: IntArray, w: Int, h: Int, fullH: Int, ox: Int, oy: Int, excl: IntArray?): TableScanResult {
        val n = w * h
        val red = BooleanArray(n)
        for (y in 0 until h) {
            val base = y * w
            for (x in 0 until w) {
                val p = px[base + x]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                if (isRed(r, g, b)) red[base + x] = true
            }
        }
        if (excl != null) {
            val xa = max(0, excl[0] - ox)
            val xb = min(w, excl[2] - ox)
            val ya = max(0, excl[1] - oy)
            val yb = min(h, excl[3] - oy)
            for (y in ya until yb) {
                for (x in xa until xb) red[y * w + x] = false
            }
        }

        // gumpalan merah (4-tetangga)
        val seen = BooleanArray(n)
        val stack = IntArray(n)
        val comps = ArrayList<IntArray>()
        for (start in 0 until n) {
            if (!red[start] || seen[start]) continue
            var sp = 0
            stack[sp] = start
            sp++
            seen[start] = true
            var area = 0
            var minx = w
            var maxx = -1
            var miny = h
            var maxy = -1
            while (sp > 0) {
                sp--
                val cur = stack[sp]
                area++
                val cy = cur / w
                val cx = cur % w
                if (cx < minx) minx = cx
                if (cx > maxx) maxx = cx
                if (cy < miny) miny = cy
                if (cy > maxy) maxy = cy
                if (cy + 1 < h) {
                    val q = cur + w
                    if (red[q] && !seen[q]) { seen[q] = true; stack[sp] = q; sp++ }
                }
                if (cy > 0) {
                    val q = cur - w
                    if (red[q] && !seen[q]) { seen[q] = true; stack[sp] = q; sp++ }
                }
                if (cx + 1 < w) {
                    val q = cur + 1
                    if (red[q] && !seen[q]) { seen[q] = true; stack[sp] = q; sp++ }
                }
                if (cx > 0) {
                    val q = cur - 1
                    if (red[q] && !seen[q]) { seen[q] = true; stack[sp] = q; sp++ }
                }
            }
            comps.add(intArrayOf(minx, miny, maxx - minx + 1, maxy - miny + 1, area))
        }

        // kandidat garis tengah kartu
        val maxT = max(3, (0.005 * fullH).toInt())
        val minL = (0.02 * fullH).toInt()
        val maxL = (0.06 * fullH).toInt()
        val cands = ArrayList<DividerCand>()
        for (c in comps) {
            val bw = c[2]
            val bh = c[3]
            val area = c[4]
            val len = max(bw, bh)
            val t = min(bw, bh)
            if (len < minL || len > maxL) continue
            if (t > maxT) continue
            if (len < 8 * t) continue
            if (area < 0.6 * len * t) continue
            val horiz = bw > bh
            val d = t + 4
            var cnt = 0
            for (f in 1..3) {
                val fr = f * 0.25
                if (horiz) {
                    val xx = c[0] + (bw * fr).toInt()
                    if (insideTile(px, w, h, xx, c[1] - d)) cnt++
                    if (insideTile(px, w, h, xx, c[1] + bh - 1 + d)) cnt++
                } else {
                    val yy = c[1] + (bh * fr).toInt()
                    if (insideTile(px, w, h, c[0] - d, yy)) cnt++
                    if (insideTile(px, w, h, c[0] + bw - 1 + d, yy)) cnt++
                }
            }
            if (cnt >= 5) cands.add(DividerCand(c[0], c[1], bw, bh, horiz, len))
        }
        if (cands.isEmpty()) return TableScanResult(emptyList(), 0, emptyList())

        val lens = cands.map { it.len }.sorted()
        val unit = lens[lens.size / 2]
        val half = (unit * 1.25).toInt()
        val m = (unit * 0.12).toInt()
        val inner = (unit * 0.08).toInt()
        val gapC = (unit * 0.10).toInt()

        // titik (pip) = gumpalan bulat berukuran sesuai
        val pipX = ArrayList<Double>()
        val pipY = ArrayList<Double>()
        for (c in comps) {
            val bw = c[2]
            val bh = c[3]
            val area = c[4]
            val aspect = bw.toDouble() / bh
            if (area >= 0.03 * unit * unit && area <= 0.35 * unit * unit &&
                aspect >= 0.55 && aspect <= 1.8 && area >= 0.3 * bw * bh
            ) {
                pipX.add(c[0] + bw / 2.0)
                pipY.add(c[1] + bh / 2.0)
            }
        }
        fun countIn(xa: Int, xb: Int, ya: Int, yb: Int): Int {
            var k = 0
            for (i in 0 until pipX.size) {
                val px0 = pipX[i]
                val py0 = pipY[i]
                if (px0 >= xa && px0 < xb && py0 >= ya && py0 < yb) k++
            }
            return k
        }

        val tiles = ArrayList<TableTile>()
        val problems = ArrayList<String>()
        var mask = 0
        var partial = 0
        for (c in cands) {
            if (c.len < 0.85 * unit || c.len > 1.15 * unit) continue
            val cx = c.x + c.bw / 2
            val cy = c.y + c.bh / 2
            // kartu horizontal = garis tengahnya tegak
            val tileHorizontal = !c.horiz
            if (excl != null) {
                val side = (unit * 0.62).toInt()
                val tx0: Int
                val tx1: Int
                val ty0: Int
                val ty1: Int
                if (tileHorizontal) {
                    tx0 = cx - half + ox; tx1 = cx + half + ox; ty0 = cy - side + oy; ty1 = cy + side + oy
                } else {
                    tx0 = cx - side + ox; tx1 = cx + side + ox; ty0 = cy - half + oy; ty1 = cy + half + oy
                }
                if (tx0 < excl[2] && tx1 > excl[0] && ty0 < excl[3] && ty1 > excl[1]) {
                    partial++
                    continue
                }
            }
            val a: Int
            val b: Int
            if (c.horiz) {
                a = countIn(c.x - m, c.x + c.bw + m, cy - half + inner, cy - gapC)
                b = countIn(c.x - m, c.x + c.bw + m, cy + gapC, cy + half - inner)
            } else {
                a = countIn(cx - half + inner, cx - gapC, c.y - m, c.y + c.bh + m)
                b = countIn(cx + gapC, cx + half - inner, c.y - m, c.y + c.bh + m)
            }
            var ok = a in 0..6 && b in 0..6
            if (ok) {
                val idx = Tiles.index(a, b)
                if (((mask shr idx) and 1) == 1) {
                    ok = false
                    problems.add("kartu " + Tiles.label(idx) + " terbaca dobel (kemungkinan salah baca)")
                } else {
                    mask = mask or (1 shl idx)
                }
            } else {
                problems.add("ada kartu dengan titik tidak jelas (" + a + "|" + b + ")")
            }
            tiles.add(TableTile(a, b, cx + ox, cy + oy, tileHorizontal, ok))
        }
        if (partial > 0) problems.add(partial.toString() + " kartu tertutup panel, dilewati")
        return TableScanResult(tiles, mask, problems)
    }
}
