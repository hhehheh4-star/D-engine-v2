package com.domino.engine.vision

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.Build
import android.view.Display
import java.util.concurrent.Executor

class ScanOutcome(
    val mask: Int,
    val tiles: List<ScannedTile>,
    val problems: List<String>,
    val error: String?
)

class TableOutcome(
    val tiles: List<TableTile>,
    val mask: Int,
    val problems: List<String>,
    val error: String?
)

/**
 * Ambil screenshot lewat AccessibilityService.takeScreenshot (Android 11+): tanpa dialog rekam layar,
 * tanpa internet, tidak ada gambar yang disimpan atau dikirim. Bitmap hanya diproses di memori lalu dibuang.
 */
object ScreenGrabber {

    private fun failHand(msg: String) = ScanOutcome(0, emptyList(), emptyList(), msg)
    private fun failTable(msg: String) = TableOutcome(emptyList(), 0, emptyList(), msg)

    /** Inti: ambil bitmap lunak (ARGB_8888) atau panggil onFail dengan pesan. */
    private fun withBitmap(
        svc: AccessibilityService,
        exec: Executor,
        onFail: (String) -> Unit,
        block: (Bitmap) -> Unit
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            onFail("Scan layar butuh Android 11 ke atas")
            return
        }
        try {
            svc.takeScreenshot(
                Display.DEFAULT_DISPLAY,
                exec,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        var soft: Bitmap? = null
                        var err: String? = null
                        try {
                            val hb = result.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                            if (hw == null) {
                                err = "Screenshot kosong"
                            } else {
                                soft = hw.copy(Bitmap.Config.ARGB_8888, false)
                                hw.recycle()
                            }
                            hb.close()
                        } catch (e: Throwable) {
                            err = "Gagal memproses screenshot: " + e.message
                        }
                        if (soft == null) {
                            onFail(err ?: "Gagal menyalin screenshot")
                        } else {
                            try {
                                block(soft)
                            } finally {
                                soft.recycle()
                            }
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        val hint = when (errorCode) {
                            3 -> "terlalu cepat, coba lagi sebentar"
                            5 -> "layar ini diblokir game (secure window)"
                            else -> "kode $errorCode"
                        }
                        onFail("Screenshot gagal: $hint")
                    }
                }
            )
        } catch (e: Throwable) {
            onFail("Tidak bisa ambil screenshot: " + e.message)
        }
    }

    // ---- kartu tangan ----

    fun grab(svc: AccessibilityService, exec: Executor, cb: (ScanOutcome) -> Unit) {
        withBitmap(svc, exec, { msg -> cb(failHand(msg)) }) { bmp ->
            cb(analyzeHand(bmp))
        }
    }

    private fun analyzeHand(bmp: Bitmap): ScanOutcome {
        val w = bmp.width
        val h = bmp.height
        // coba pita bawah dulu (tangan biasanya di sini), lalu pita lebih tinggi
        val tops = doubleArrayOf(0.55, 0.38)
        for (top in tops) {
            val y0 = (h * top).toInt()
            val y1 = (h * 0.98).toInt()
            val bh = y1 - y0
            if (bh <= 0) continue
            val px = IntArray(w * bh)
            bmp.getPixels(px, 0, w, 0, y0, w, bh)
            val r = HandScanner.scan(px, w, bh, h)
            if (r.tiles.isNotEmpty()) return ScanOutcome(r.mask, r.tiles, r.problems, null)
        }
        return failHand("Kartu tidak terlihat. Pastikan 7 kartu tampil di layar lalu scan lagi.")
    }

    // ---- kartu di meja ----

    /** @param excl area layar yang ditutup overlay kita [kiri, atas, kanan, bawah], atau null kalau panel disembunyikan */
    fun grabTable(svc: AccessibilityService, exec: Executor, excl: IntArray?, cb: (TableOutcome) -> Unit) {
        withBitmap(svc, exec, { msg -> cb(failTable(msg)) }) { bmp ->
            val w = bmp.width
            val h = bmp.height
            val ox = (w * 0.12).toInt()
            val oy = (h * 0.15).toInt()
            val rw = (w * 0.88).toInt() - ox
            val rh = (h * 0.90).toInt() - oy
            if (rw <= 0 || rh <= 0) {
                cb(failTable("Ukuran layar tidak valid"))
            } else {
                val px = IntArray(rw * rh)
                bmp.getPixels(px, 0, rw, ox, oy, rw, rh)
                val r = TableScanner.scan(px, rw, rh, h, ox, oy, excl)
                cb(TableOutcome(r.tiles, r.mask, r.problems, null))
            }
        }
    }
}
