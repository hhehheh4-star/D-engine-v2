package com.domino.engine.overlay

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Layanan aksesibilitas. Di Tahap 1 dipakai sebagai cadangan jendela overlay
 * (TYPE_ACCESSIBILITY_OVERLAY) kalau izin "tampil di atas aplikasi lain" belum diberikan.
 * Tahap 2: dipakai untuk takeScreenshot (Android 11+) agar kartu tangan terbaca otomatis.
 *
 * Layanan ini TIDAK membaca isi layar, TIDAK punya izin gesture, dan tidak pernah menekan layar.
 */
class DominoAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // sengaja kosong
    }

    override fun onInterrupt() {
        // sengaja kosong
    }

    companion object {
        @Volatile
        var instance: DominoAccessibilityService? = null
    }
}
