package com.domino.engine.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.domino.engine.overlay.DominoAccessibilityService
import com.domino.engine.overlay.OverlayService

/** Layar utama: izin, mulai/stop overlay, pengaturan waktu hitung. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var budgetInfo: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(16))

        val title = TextView(this)
        title.text = "Domino Engine"
        title.textSize = 24f
        title.typeface = Typeface.DEFAULT_BOLD
        col.addView(title)

        val sub = TextView(this)
        sub.text = "Asisten petunjuk gaple mengambang (Tahap 3: scan kartu tangan + scan meja + input kartu bergambar + rekomendasi)."
        sub.textSize = 13f
        col.addView(sub)

        status = TextView(this)
        status.textSize = 14f
        status.setPadding(0, dp(12), 0, dp(12))
        col.addView(status)

        col.addView(btn("1. Izinkan tampil di atas aplikasi lain (Overlay)") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(btn("2. Aktifkan Aksesibilitas (cadangan overlay + Tahap 2)") {
            Toast.makeText(
                this,
                "Cari 'Domino Engine' di daftar layanan lalu aktifkan",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("▶ Mulai Overlay") {
            if (Settings.canDrawOverlays(this) || DominoAccessibilityService.instance != null) {
                OverlayService.start(this)
                Toast.makeText(this, "Overlay aktif. Buka game gaple lu.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Aktifkan izin Overlay dulu (langkah 1)", Toast.LENGTH_LONG).show()
            }
        })
        col.addView(btn("■ Stop Overlay") { OverlayService.stop(this) })

        val bt = TextView(this)
        bt.text = "Waktu hitung rekomendasi (makin lama makin akurat):"
        bt.setPadding(0, dp(16), 0, 0)
        col.addView(bt)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (ms in listOf(1000L, 2500L, 5000L)) {
            val b = Button(this)
            b.text = "${ms / 1000.0} dtk"
            b.setOnClickListener {
                getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE)
                    .edit().putLong(OverlayService.KEY_BUDGET_MS, ms).apply()
                refresh()
            }
            row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(row)

        budgetInfo = TextView(this)
        budgetInfo.textSize = 12f
        col.addView(budgetInfo)

        val help = TextView(this)
        help.text = "\nCara pakai:\n" +
            "1) Mulai Overlay, buka game.\n" +
            "2) Awal ronde: tap 📷 SCAN 7 KARTU (otomatis dari layar, offline, butuh Aksesibilitas aktif + Android 11+). Kalau ada yang salah, koreksi manual di grid lalu pilih siapa yang mulai.\n" +
            "3) Giliran lawan: tap angka ujung baru lalu panah arah (atau PASS). Giliran otomatis searah jarum jam.\n" +
            "4) Giliran lu: panel menampilkan kartu terbaik. Mainkan di game, lalu tap kartu itu di panel.\n\n" +
            "Aplikasi ini tidak pernah menekan layar atau bermain otomatis."
        help.textSize = 13f
        col.addView(help)

        val scroll = ScrollView(this)
        scroll.addView(col)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val acc = DominoAccessibilityService.instance != null
        status.text = "Overlay: " + (if (overlay) "✔ diizinkan" else "✘ belum") +
            "\nAksesibilitas: " + (if (acc) "✔ aktif" else "✘ belum") +
            "\nStatus overlay: " + (if (OverlayService.running) "berjalan" else "mati")
        val ms = getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE)
            .getLong(OverlayService.KEY_BUDGET_MS, 2500L)
        budgetInfo.text = "Sekarang: ${ms / 1000.0} detik per giliran."
    }

    private fun btn(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }
}
