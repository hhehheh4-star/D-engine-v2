package com.domino.engine

import com.domino.engine.ai.Analysis
import com.domino.engine.ai.HiddenSampler
import com.domino.engine.ai.MonteCarloEngine
import com.domino.engine.core.GameState
import com.domino.engine.core.PassRecord
import com.domino.engine.core.Phase
import com.domino.engine.core.Rules
import com.domino.engine.core.Session
import com.domino.engine.core.Side
import com.domino.engine.core.Tiles
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.SplittableRandom

class CoreAndAiTest {

    private fun bit(a: Int, b: Int) = 1 shl Tiles.index(a, b)

    @Test
    fun deckHas28UniqueTiles() {
        val seen = HashSet<Int>()
        var mask = 0
        for (a in 0..6) for (b in a..6) {
            seen.add(Tiles.index(a, b))
            mask = mask or bit(a, b)
        }
        assertEquals(28, seen.size)
        assertEquals(Tiles.ALL, mask)
    }

    @Test
    fun firstMoveAllowsAnyTile() {
        val hand = bit(0, 0) or bit(3, 5)
        val moves = Rules.legalMoves(hand, -1, -1)
        assertEquals(2, moves.size)
        assertTrue(moves.all { it.side == Side.FIRST })
    }

    @Test
    fun legalMovesFollowEnds() {
        val hand = bit(3, 5) or bit(1, 2) or bit(3, 3)
        val moves = Rules.legalMoves(hand, 3, 6)
        assertEquals(2, moves.size)
        assertTrue(moves.all { it.side == Side.LEFT })
    }

    @Test
    fun equalEndsListOnlyOneSide() {
        val hand = bit(3, 5)
        val moves = Rules.legalMoves(hand, 3, 3)
        assertEquals(1, moves.size)
    }

    @Test
    fun blockedWinnersReturnsAllTies() {
        assertEquals(listOf(1, 3), Rules.blockedWinners(intArrayOf(10, 5, 12, 5)))
        assertEquals(listOf(2), Rules.blockedWinners(intArrayOf(10, 9, 3, 5)))
    }

    private fun sessionWithHand(): Session {
        val s = Session()
        val hand = listOf(
            Tiles.index(0, 0), Tiles.index(0, 1), Tiles.index(1, 1), Tiles.index(2, 2),
            Tiles.index(3, 4), Tiles.index(5, 6), Tiles.index(4, 4)
        )
        for (t in hand) assertNull(s.toggleHandTile(t))
        return s
    }

    @Test
    fun handEntryThenStarter() {
        val s = sessionWithHand()
        assertEquals(Phase.PICK_STARTER, s.state.phase)
        assertNull(s.setStarter(1))
        assertEquals(Phase.PLAYING, s.state.phase)
        assertEquals(1, s.state.turn)
    }

    @Test
    fun turnsGoClockwiseAndPassKeepsEndsAtThatTime() {
        val s = sessionWithHand()
        s.setStarter(1)
        assertNull(s.play(Tiles.index(3, 3), Side.FIRST))      // P2 buka 3-3
        assertEquals(2, s.state.turn)
        assertNull(s.pass())                                    // P3 pass di ujung 3|3
        assertEquals(3, s.state.turn)
        assertNull(s.play(Tiles.index(3, 6), Side.LEFT))        // P4 main 6-3 di kiri => 6|3
        assertEquals(0, s.state.turn)
        assertEquals(6, s.state.left)
        assertEquals(3, s.state.right)
        assertNotNull(s.pass())                                 // kita masih punya kartu legal
        assertNull(s.play(Tiles.index(5, 6), Side.LEFT))        // kita main 5-6 => 5|3
        assertEquals(1, s.state.turn)
        assertNull(s.pass())                                    // P2 pass di ujung 5|3
        val passes = s.state.passes
        assertEquals(PassRecord(2, 3, 3), passes[0])
        assertEquals(PassRecord(1, 5, 3), passes[1])
    }

    @Test
    fun cannotPlayTileInMyHandForOpponent() {
        val s = sessionWithHand()
        s.setStarter(1)
        assertNotNull(s.play(Tiles.index(0, 0), Side.FIRST))
    }

    @Test
    fun fourPassesBlockTheGame() {
        val s = sessionWithHand()
        s.setStarter(1)
        s.play(Tiles.index(6, 6), Side.FIRST) // ujung 6|6, kita punya 5-6 jadi kita tidak boleh pass
        assertNull(s.pass()) // P3
        assertNull(s.pass()) // P4
        assertNotNull(s.pass()) // kita punya 5-6 => tidak boleh pass
        s.play(Tiles.index(5, 6), Side.LEFT)
        assertNull(s.pass()) // P2 pass di ujung 5|6
        assertNull(s.pass()) // P3
        assertNull(s.pass()) // P4
        assertEquals(0, s.state.turn)
        // kita punya 3-4 dan 4-4, tidak ada yang cocok dengan 5|6? 5 dan 6 -> tidak ada, kita boleh pass
        assertNull(s.pass())
        assertEquals(Phase.OVER, s.state.phase)
    }

    @Test
    fun undoRestoresState() {
        val s = sessionWithHand()
        s.setStarter(2)
        s.play(Tiles.index(2, 5), Side.FIRST)
        assertTrue(s.undo())
        assertEquals(2, s.state.turn)
        assertTrue(s.state.boardEmpty)
    }

    @Test
    fun samplerRespectsCountsAndPassConstraints() {
        val myHand = (0 until 7).fold(0) { acc, t -> acc or (1 shl t) }
        val state = GameState(
            phase = Phase.PLAYING,
            myHand = myHand,
            left = 3,
            right = 5,
            counts = listOf(7, 7, 7, 7),
            turn = 0,
            passes = listOf(PassRecord(1, 3, 5))
        )
        val sampler = HiddenSampler(state, SplittableRandom(42))
        val hands = IntArray(4)
        val unseen = state.unseen()
        repeat(300) {
            assertTrue(sampler.sample(hands))
            for (p in 1..3) assertEquals(7, Integer.bitCount(hands[p]))
            assertEquals(0, hands[1] and Tiles.numberMask[3])
            assertEquals(0, hands[1] and Tiles.numberMask[5])
            assertEquals(0, hands[1] and hands[2])
            assertEquals(0, hands[1] and hands[3])
            assertEquals(0, hands[2] and hands[3])
            assertEquals(unseen, hands[1] or hands[2] or hands[3])
        }
    }

    @Test
    fun lastTileThatFitsWinsWithCertainty() {
        val played = bit(0, 0) or bit(0, 1) or bit(1, 1) or bit(0, 2) or bit(1, 2) or bit(2, 2)
        val state = GameState(
            phase = Phase.PLAYING,
            myHand = bit(3, 5),
            played = played,
            left = 3,
            right = 6,
            counts = listOf(1, 7, 7, 7),
            turn = 0
        )
        var last: Analysis? = null
        MonteCarloEngine(7L).analyze(state, 50L, { false }) { last = it }
        val a = last!!
        assertTrue(a.done)
        assertEquals(1, a.moves.size)
        assertEquals(1.0, a.moves[0].winProb, 1e-9)
        assertTrue(a.samples > 0)
    }
}
